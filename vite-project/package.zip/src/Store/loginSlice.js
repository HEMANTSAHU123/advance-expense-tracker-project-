import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { signInWithEmailAndPassword, sendEmailVerification } from 'firebase/auth';
import { auth } from '../firebase/firebase'; 


export const loginUser = createAsyncThunk(

    async ({ email, password }, { rejectWithValue }) => {
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;
            if (!user.emailVerified) {
                await sendEmailVerification(user);
              
                return rejectWithValue('Email not verified');
            }
            return { user };
        } catch (error) {
            return rejectWithValue(error.message);
        }
    }
);

 export const loginSlice = createSlice({
    name: 'login',
    initialState: {
        user: null,
        isLoading: false,
        error: null,
        emailVerificationSent: false, 
    },
    reducers: {
        resetLoginState: (state) => {
            state.isLoading = false;
            state.error = null;
            state.emailVerificationSent = false;
        },
        setEmailVerificationSent: (state) => {
            state.emailVerificationSent = true;
        },
    },
   
});

export const { resetLoginState, setEmailVerificationSent } = loginSlice.actions;
//export default loginSlice.reducer;